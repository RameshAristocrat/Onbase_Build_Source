(self["webpackChunkrdap"] = self["webpackChunkrdap"] || []).push([["src_app_package_modules_data-warehouse_onbase-explorer-configs_module_ts"],{

/***/ 37373:
/*!**********************************************************************************************************************************!*\
  !*** ./src/app/package/modules/data-warehouse/explorer/onbase-explorer-common-search/onbase-explorer-common-search.component.ts ***!
  \**********************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OnbaseExplorerCommonSearchComponent": function() { return /* binding */ OnbaseExplorerCommonSearchComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/snack-bar */ 77001);
/* harmony import */ var src_app_package_core_okta_auth_okta_auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/package/core/okta-auth/okta-auth-service */ 59841);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/expansion */ 1562);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/card */ 93738);
/* harmony import */ var _core_core_shared_components_onbase_shared_explorer_search_onbase_shared_explorer_search_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../core/core-shared-components/onbase-shared-explorer-search/onbase-shared-explorer-search.component */ 284);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/button */ 51095);
/* harmony import */ var _core_core_shared_components_onbase_shared_explorer_search_onbase_shared_explorer_search_results_onbase_shared_explorer_search_results_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../core/core-shared-components/onbase-shared-explorer-search/onbase-shared-explorer-search-results/onbase-shared-explorer-search-results.component */ 810);












class OnbaseExplorerCommonSearchComponent {
    constructor(httpClient, location, _router, fb, _snackBar, okta) {
        this.httpClient = httpClient;
        this._router = _router;
        this.fb = fb;
        this._snackBar = _snackBar;
        this.okta = okta;
        this.httpClient.get("assets/api/master-api.json").subscribe(data => {
            this.apiConfigData = data;
        });
        this.panelOpenState = true;
    }
    ngOnInit() {
        this.panelOpenState = true;
    }
    searchfilterdata(event) {
        this.searchFilterData = event;
    }
    searcSubmit() {
        let basedoctype = this.searchFilterData.basesearchform.get('basedocumenttype').value;
        let apiTempValue;
        this.searchGridData = [];
        this.gridsource = [];
        if (basedoctype == "ACH") {
            this.httpClient.get("assets/config/search-data-mockup.json").subscribe(data => {
                this.gridsource.push(data);
                this.gridsource.filter(x => {
                    x.filter(y => {
                        if (basedoctype == y.documenttype) {
                            this.searchGridData = y.data;
                        }
                        ;
                    });
                });
            });
        }
        else {
            this.apiConfigData.filter(x => {
                if (x.documenttype == basedoctype) {
                    this.apiEndpointUrl = x.endpoint;
                    this.apiParam = x.param;
                    Object.keys(this.apiParam[0]).forEach(x => {
                        if (x == "Vendor_Name") {
                            apiTempValue = this.searchFilterData.doctypesearchform.get(x).value;
                            this.apiEndpointUrl = this.apiEndpointUrl + "&" + x + "=" + apiTempValue["id"];
                        }
                        else if (x == "Page_Size") {
                            this.apiEndpointUrl = this.apiEndpointUrl + "&" + x + "=" + 25;
                        }
                        else if (x == "Page_Nbr") {
                            this.apiEndpointUrl = this.apiEndpointUrl + "&" + x + "=" + 1;
                        }
                        else {
                            apiTempValue = null;
                            this.apiEndpointUrl = this.apiEndpointUrl + "&" + x + "=" + null;
                        }
                    });
                }
            });
            this.httpClient.get(this.apiEndpointUrl).subscribe(data => {
                this.searchGridData = data;
            });
        }
    }
}
OnbaseExplorerCommonSearchComponent.ɵfac = function OnbaseExplorerCommonSearchComponent_Factory(t) { return new (t || OnbaseExplorerCommonSearchComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_5__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_material_snack_bar__WEBPACK_IMPORTED_MODULE_8__.MatSnackBar), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_package_core_okta_auth_okta_auth_service__WEBPACK_IMPORTED_MODULE_0__.OktaAuthService)); };
OnbaseExplorerCommonSearchComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: OnbaseExplorerCommonSearchComponent, selectors: [["app-onbase-explorer-common-search"]], decls: 21, vars: 2, consts: [[1, "grid-container"], [2, "padding-left", "1%", "padding-bottom", "1%", "padding-right", "1%"], [3, "expanded", "opened", "closed"], [2, "font-weight", "410"], [3, "searchfilterdata"], [2, "text-align", "left"], ["mat-raised-button", "", 2, "width", "10%", "background-color", "#300c46", "color", "white", 3, "click"], ["mat-raised-button", "", 2, "width", "10%", "background-color", "#300c46", "color", "white"], [2, "padding-left", "1%"], [3, "searchGridData"]], template: function OnbaseExplorerCommonSearchComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "mat-accordion");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "mat-expansion-panel", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("opened", function OnbaseExplorerCommonSearchComponent_Template_mat_expansion_panel_opened_3_listener() { return ctx.panelOpenState = true; })("closed", function OnbaseExplorerCommonSearchComponent_Template_mat_expansion_panel_closed_3_listener() { return ctx.panelOpenState = false; });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "mat-expansion-panel-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "mat-panel-title", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6, " Document Search Filter ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "mat-card");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "mat-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "app-onbase-shared-explorer-search", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("searchfilterdata", function OnbaseExplorerCommonSearchComponent_Template_app_onbase_shared_explorer_search_searchfilterdata_9_listener($event) { return ctx.searchfilterdata($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "mat-card-actions", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function OnbaseExplorerCommonSearchComponent_Template_button_click_11_listener() { return ctx.searcSubmit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12, "Search");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](14, "Reset");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "mat-card");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](17, "mat-card-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](19, "Search Result");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](20, "app-onbase-shared-explorer-search-results", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("expanded", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("searchGridData", ctx.searchGridData);
    } }, directives: [_angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__.MatAccordion, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__.MatExpansionPanel, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__.MatExpansionPanelHeader, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_9__.MatExpansionPanelTitle, _angular_material_card__WEBPACK_IMPORTED_MODULE_10__.MatCard, _angular_material_card__WEBPACK_IMPORTED_MODULE_10__.MatCardContent, _core_core_shared_components_onbase_shared_explorer_search_onbase_shared_explorer_search_component__WEBPACK_IMPORTED_MODULE_1__.OnbaseSharedExplorerSearchComponent, _angular_material_card__WEBPACK_IMPORTED_MODULE_10__.MatCardActions, _angular_material_button__WEBPACK_IMPORTED_MODULE_11__.MatButton, _core_core_shared_components_onbase_shared_explorer_search_onbase_shared_explorer_search_results_onbase_shared_explorer_search_results_component__WEBPACK_IMPORTED_MODULE_2__.OnbaseSharedExplorerSearchResultsComponent], styles: [".grid-container[_ngcontent-%COMP%] {\n  margin: 0px;\n}\n\n.mat-form-field[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n[_nghost-%COMP%]  .mat-form-field .mat-input-element {\n  margin-top: 0.9em !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9uYmFzZS1leHBsb3Jlci1jb21tb24tc2VhcmNoLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBVztBQUNmOztBQUdFO0VBQ0UsV0FBVztBQUFmOztBQUdBO0VBRVEsNEJBQTRCO0FBRHBDIiwiZmlsZSI6Im9uYmFzZS1leHBsb3Jlci1jb21tb24tc2VhcmNoLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmdyaWQtY29udGFpbmVyIHtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gICAgLy9taW4taGVpZ2h0OmNhbGMoMTAwdmggLSAxMDBweCk7IFxyXG4gIH1cclxuXHJcbiAgLm1hdC1mb3JtLWZpZWxke1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbjpob3N0OjpuZy1kZWVwIC5tYXQtZm9ybS1maWVsZCB7XHJcbiAgICAubWF0LWlucHV0LWVsZW1lbnQge1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDAuOWVtICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn0iXX0= */"] });


/***/ }),

/***/ 44361:
/*!***********************************************************************************!*\
  !*** ./src/app/package/modules/data-warehouse/onbase-explorer-configs-routing.ts ***!
  \***********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "onbaseExplorerRoutes": function() { return /* binding */ onbaseExplorerRoutes; }
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _explorer_onbase_explorer_common_search_onbase_explorer_common_search_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./explorer/onbase-explorer-common-search/onbase-explorer-common-search.component */ 37373);


const routes = [
    {
        path: "search",
        component: _explorer_onbase_explorer_common_search_onbase_explorer_common_search_component__WEBPACK_IMPORTED_MODULE_0__.OnbaseExplorerCommonSearchComponent
    }
];
const onbaseExplorerRoutes = _angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterModule.forChild(routes);


/***/ }),

/***/ 27779:
/*!**********************************************************************************!*\
  !*** ./src/app/package/modules/data-warehouse/onbase-explorer-configs.module.ts ***!
  \**********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OnbaseExplorerConfigModule": function() { return /* binding */ OnbaseExplorerConfigModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/grid-list */ 4929);
/* harmony import */ var _angular_material_card__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/card */ 93738);
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/menu */ 33935);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/icon */ 76627);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/button */ 51095);
/* harmony import */ var _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/cdk/layout */ 65072);
/* harmony import */ var _mat_modules_material_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../mat-modules/material.module */ 54364);
/* harmony import */ var _onbase_explorer_configs_routing__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./onbase-explorer-configs-routing */ 44361);
/* harmony import */ var _core_core_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/core.module */ 37713);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _explorer_onbase_explorer_common_search_onbase_explorer_common_search_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./explorer/onbase-explorer-common-search/onbase-explorer-common-search.component */ 37373);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 39895);














class OnbaseExplorerConfigModule {
}
OnbaseExplorerConfigModule.ɵfac = function OnbaseExplorerConfigModule_Factory(t) { return new (t || OnbaseExplorerConfigModule)(); };
OnbaseExplorerConfigModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({ type: OnbaseExplorerConfigModule });
OnbaseExplorerConfigModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _onbase_explorer_configs_routing__WEBPACK_IMPORTED_MODULE_1__.onbaseExplorerRoutes,
            _mat_modules_material_module__WEBPACK_IMPORTED_MODULE_0__.MaterialModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _core_core_module__WEBPACK_IMPORTED_MODULE_2__.CoreModule,
            _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_7__.MatGridListModule,
            _angular_material_card__WEBPACK_IMPORTED_MODULE_8__.MatCardModule,
            _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__.MatMenuModule,
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__.MatIconModule,
            _angular_material_button__WEBPACK_IMPORTED_MODULE_11__.MatButtonModule,
            _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_12__.LayoutModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](OnbaseExplorerConfigModule, { declarations: [_explorer_onbase_explorer_common_search_onbase_explorer_common_search_component__WEBPACK_IMPORTED_MODULE_3__.OnbaseExplorerCommonSearchComponent], imports: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_13__.RouterModule, _mat_modules_material_module__WEBPACK_IMPORTED_MODULE_0__.MaterialModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
        _core_core_module__WEBPACK_IMPORTED_MODULE_2__.CoreModule,
        _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_7__.MatGridListModule,
        _angular_material_card__WEBPACK_IMPORTED_MODULE_8__.MatCardModule,
        _angular_material_menu__WEBPACK_IMPORTED_MODULE_9__.MatMenuModule,
        _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__.MatIconModule,
        _angular_material_button__WEBPACK_IMPORTED_MODULE_11__.MatButtonModule,
        _angular_cdk_layout__WEBPACK_IMPORTED_MODULE_12__.LayoutModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_package_modules_data-warehouse_onbase-explorer-configs_module_ts-es2015.js.map